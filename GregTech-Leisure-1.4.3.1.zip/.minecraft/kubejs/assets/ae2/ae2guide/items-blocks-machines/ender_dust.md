---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 末影粉
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# 末影粉

<ItemImage id="ender_dust" scale="4" />

被<ItemLink id="inscriber" />粉碎的末影珍珠。用于制造<ItemLink id="wireless_booster" />和<ItemLink id="quantum_entangled_singularity" />对。

## 配方

<RecipeFor id="ender_dust" />
